<template>
  <section class="blog-one blog-page">
      <div class="container">
          <div class="row">
              <div class="col-lg-4">
                  <div class="blog-one__single">
                      <div class="blog-one__image">
                          <img src="/assets/images/success1.jpg" alt="">
                          <nuxt-link class="blog-one__plus" to="#"><i class="kipso-icon-plus-symbol"></i>
                              <!-- /.kipso-icon-plus-symbol --></nuxt-link>
                      </div><!-- /.blog-one__image -->
                      <div class="blog-one__content text-center">
                          <div class="blog-one__meta">
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted On Jan 19"><i class="fa fa-calendar-alt"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="No Comments"><i class="fa fa-comments"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted By Admin"><i class="fa fa-user"></i></a>
                          </div><!-- /.blog-one__meta -->
                          <h2 class="blog-one__title"><nuxt-link to="#">Avocado Project Cameroon</nuxt-link>
                          </h2><!-- /.blog-one__title -->
                          <p class="blog-one__text">Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit
                              amet finibus eros.</p><!-- /.blog-one__text -->
                          <nuxt-link to="#" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
                      </div><!-- /.blog-one__content -->
                  </div><!-- /.blog-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4">
                  <div class="blog-one__single">
                      <div class="blog-one__image">
                          <img src="/assets/images/success1.jpg" alt="">
                          <nuxt-link class="blog-one__plus" to="#"><i class="kipso-icon-plus-symbol"></i>
                              <!-- /.kipso-icon-plus-symbol --></nuxt-link>
                      </div><!-- /.blog-one__image -->
                      <div class="blog-one__content text-center">
                          <div class="blog-one__meta">
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted On Jan 19"><i class="fa fa-calendar-alt"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="No Comments"><i class="fa fa-comments"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted By Admin"><i class="fa fa-user"></i></a>
                          </div><!-- /.blog-one__meta -->
                          <h2 class="blog-one__title"><nuxt-link to="#">Avocado Project Cameroon</nuxt-link>
                          </h2><!-- /.blog-one__title -->
                          <p class="blog-one__text">Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit
                              amet finibus eros.</p><!-- /.blog-one__text -->
                        <nuxt-link to="#" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
                      </div><!-- /.blog-one__content -->
                  </div><!-- /.blog-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4">
                  <div class="blog-one__single">
                      <div class="blog-one__image">
                          <img src="/assets/images/success1.jpg" alt="">
                        <nuxt-link class="blog-one__plus" to="#"><i class="kipso-icon-plus-symbol"></i>
                                                      <!-- /.kipso-icon-plus-symbol --></nuxt-link>
                      </div><!-- /.blog-one__image -->
                      <div class="blog-one__content text-center">
                          <div class="blog-one__meta">
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted On Jan 19"><i class="fa fa-calendar-alt"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="No Comments"><i class="fa fa-comments"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted By Admin"><i class="fa fa-user"></i></a>
                          </div><!-- /.blog-one__meta -->
                          <h2 class="blog-one__title"><nuxt-link to="#">Avocado Project Cameroon</nuxt-link>
                          </h2><!-- /.blog-one__title -->
                          <p class="blog-one__text">Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit
                              amet finibus eros.</p><!-- /.blog-one__text -->
                        <nuxt-link to="#" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
                      </div><!-- /.blog-one__content -->
                  </div><!-- /.blog-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4">
                  <div class="blog-one__single">
                      <div class="blog-one__image">
                          <img src="/assets/images/success1.jpg" alt="">
                        <nuxt-link class="blog-one__plus" to="#"><i class="kipso-icon-plus-symbol"></i>
                                                      <!-- /.kipso-icon-plus-symbol --></nuxt-link>
                      </div><!-- /.blog-one__image -->
                      <div class="blog-one__content text-center">
                          <div class="blog-one__meta">
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted On Jan 19"><i class="fa fa-calendar-alt"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="No Comments"><i class="fa fa-comments"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted By Admin"><i class="fa fa-user"></i></a>
                          </div><!-- /.blog-one__meta -->
                          <h2 class="blog-one__title"><nuxt-link to="#">Avocado Project Cameroon</nuxt-link>
                          </h2><!-- /.blog-one__title -->
                          <p class="blog-one__text">Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit
                              amet finibus eros.</p><!-- /.blog-one__text -->
                        <nuxt-link to="#" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
                      </div><!-- /.blog-one__content -->
                  </div><!-- /.blog-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4">
                  <div class="blog-one__single">
                      <div class="blog-one__image">
                          <img src="/assets/images/success1.jpg" alt="">
                        <nuxt-link class="blog-one__plus" to="#"><i class="kipso-icon-plus-symbol"></i>
                                                      <!-- /.kipso-icon-plus-symbol --></nuxt-link>
                      </div><!-- /.blog-one__image -->
                      <div class="blog-one__content text-center">
                          <div class="blog-one__meta">
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted On Jan 19"><i class="fa fa-calendar-alt"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="No Comments"><i class="fa fa-comments"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted By Admin"><i class="fa fa-user"></i></a>
                          </div><!-- /.blog-one__meta -->
                          <h2 class="blog-one__title"><nuxt-link to="#">Avocado Project Cameroon</nuxt-link>
                          </h2><!-- /.blog-one__title -->
                          <p class="blog-one__text">Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit
                              amet finibus eros.</p><!-- /.blog-one__text -->
                        <nuxt-link to="#" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
                      </div><!-- /.blog-one__content -->
                  </div><!-- /.blog-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4">
                  <div class="blog-one__single">
                      <div class="blog-one__image">
                          <img src="/assets/images/success1.jpg" alt="">
                        <nuxt-link class="blog-one__plus" to="#"><i class="kipso-icon-plus-symbol"></i>
                                                      <!-- /.kipso-icon-plus-symbol --></nuxt-link>
                      </div><!-- /.blog-one__image -->
                      <div class="blog-one__content text-center">
                          <div class="blog-one__meta">
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted On Jan 19"><i class="fa fa-calendar-alt"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="No Comments"><i class="fa fa-comments"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="" href="#" data-original-title="Posted By Admin"><i class="fa fa-user"></i></a>
                          </div><!-- /.blog-one__meta -->
                          <h2 class="blog-one__title"><nuxt-link to="#">Avocado Project Cameroon</nuxt-link>
                          </h2><!-- /.blog-one__title -->
                          <p class="blog-one__text">Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit
                              amet finibus eros.</p><!-- /.blog-one__text -->
                        <nuxt-link to="#" class="blog-one__link">Read More</nuxt-link><!-- /.blog-one__link -->
                      </div><!-- /.blog-one__content -->
                  </div><!-- /.blog-one__single -->
              </div><!-- /.col-lg-4 -->
          </div><!-- /.row -->
          <div class="post-pagination">
              <a href="#"><i class="fa fa-angle-double-left"></i><!-- /.fa fa-angle-double-left --></a>
              <a class="active" href="#">1</a>
              <a href="#">2</a>
              <a href="#">3</a>
              <a href="#">4</a>
              <a href="#"><i class="fa fa-angle-double-right"></i><!-- /.fa fa-angle-double-left --></a>
          </div><!-- /.post-pagination -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "success"
    }
</script>

<style scoped>

</style>
