<template>
  <section class="meeting-one">
      <div class="container">
          <div class="row">
              <div class="col-lg-6">
                  <div class="meeting-one__image">
                      <img src="/assets/images/meeting-1-1.jpg" alt="Awesome Image" />
                  </div><!-- /.meeting-one__image -->
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-6">
                  <div class="meeting-one__content">
                      <div class="block-title text-left">
                          <h2 class="block-title__title">Our latest news <br>
                              & articles</h2><!-- /.block-title__title -->
                      </div><!-- /.block-title -->
                      <p class="meeting-one__block-text">There are many variations of passages of lorem ipsum available,
                          but the majority have suffered alteration in some form, by injected humour, or randomised words
                          which don't look even slightly believable.</p>
                      <!-- /.meeting-one__block-text -->
                      <div class="meeting-one__box-wrap">
                          <div class="meeting-one__box">
                              <div class="meeting-one__bubble">Hello. I’m here to learn chemistry</div>
                              <!-- /.meeting-one__bubble -->
                              <img src="/assets/images/chat-1-1.jpg" alt="Awesome Image" />
                              <h3 class="meeting-one__title">Rhonda Mcdermond</h3><!-- /.meeting-one__title -->
                              <p class="meeting-one__text">Student</p><!-- /.meeting-one__text -->
                          </div><!-- /.meeting-one__box -->
                          <div class="meeting-one__box">
                              <div class="meeting-one__bubble">Hello. Rhonda</div><!-- /.meeting-one__bubble -->
                              <img src="/assets/images/chat-1-2.jpg" alt="Awesome Image" />
                              <h3 class="meeting-one__title">Karleen Pedigo</h3><!-- /.meeting-one__title -->
                              <p class="meeting-one__text">Teacher</p><!-- /.meeting-one__text -->
                          </div><!-- /.meeting-one__box -->
                      </div><!-- /.meeting-one__box-wrap -->
                  </div><!-- /.meeting-one__content -->
              </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "Meeting"
    }
</script>

<style scoped>

</style>
