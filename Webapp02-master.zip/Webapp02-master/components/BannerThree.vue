<template>
  <section class="slider-three">
              <img src="/assets/images/slider-3-icon-1-1.png" class="slider-three__icon-1" alt="">
              <img src="/assets/images/slider-3-icon-1-2.png" class="slider-three__icon-2" alt="">
              <img src="/assets/images/slider-3-icon-1-3.png" class="slider-three__icon-3" alt="">
              <img src="/assets/images/slider-3-icon-1-4.png" class="slider-three__icon-4" alt="">
              <img src="/assets/images/slider-3-icon-1-5.png" class="slider-three__icon-5" alt="">
              <div class="container">
                  <div class="row">
                      <div class="col-lg-6">
                          <div class="slider-three__content">
                              <p class="slider-three__tag-line">we can teach you anything</p><!-- /.slider-three__tag-line -->
                              <h2 class="slider-three__title">Start learning
                                  with us now</h2><!-- /.slider-three__title -->
                              <p class="slider-three__text">You need to be sure there isn't anything hidden in the middle of text
                                  lorem ipsum on the Internet.</p><!-- /.slider-three__text -->
                              <form action="#" class="slider-three__search">
                                  <input type="text" placeholder="Search courses">
                                  <button type="submit"><i class="kipso-icon-magnifying-glass"></i>
                                      <!-- /.kipso-icon-magnifying-glass --></button>
                              </form><!-- /.slider-three__search -->
                          </div><!-- /.slider-three__content -->
                      </div><!-- /.col-lg-6 -->
                  </div><!-- /.row -->
              </div><!-- /.container -->
          </section>
</template>

<script>
    export default {
        name: "BannerThree"
    }
</script>

<style scoped>

</style>
