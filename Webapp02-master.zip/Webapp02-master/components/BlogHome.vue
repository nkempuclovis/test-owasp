<template>
  <section class="blog-one  blog-one__home-two">
      <div class="container">
          <div class="block-title text-center">
              <h2 class="block-title__title">Our latest news <br>
                  & articles</h2><!-- /.block-title__title -->
          </div><!-- /.block-title -->
          <div class="row">
              <div class="col-lg-4">
                  <div class="blog-one__single">
                      <div class="blog-one__image">
                          <img src="/assets/images/blog-1-1.jpg" alt="">
                          <a class="blog-one__plus" href="/news-details"><i class="kipso-icon-plus-symbol"></i>
                              <!-- /.kipso-icon-plus-symbol --></a>
                      </div><!-- /.blog-one__image -->
                      <div class="blog-one__content text-center">
                          <div class="blog-one__meta">
                              <a data-toggle="tooltip" data-placement="top" title="Posted On Jan 19" href="#"><i class="fa fa-calendar-alt"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="No Comments" href="#"><i class="fa fa-comments"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="Posted By Admin" href="#"><i class="fa fa-user"></i></a>
                          </div><!-- /.blog-one__meta -->
                          <h2 class="blog-one__title"><a href="/news-details">Summer high school journalism camp</a>
                          </h2><!-- /.blog-one__title -->
                          <p class="blog-one__text">Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit
                              amet finibus eros.</p><!-- /.blog-one__text -->
                          <a href="/news-details" class="blog-one__link">Read More</a><!-- /.blog-one__link -->
                      </div><!-- /.blog-one__content -->
                  </div><!-- /.blog-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4">
                  <div class="blog-one__single">
                      <div class="blog-one__image">
                          <img src="/assets/images/blog-1-2.jpg" alt="">
                          <a class="blog-one__plus" href="/news-details"><i class="kipso-icon-plus-symbol"></i>
                              <!-- /.kipso-icon-plus-symbol --></a>
                      </div><!-- /.blog-one__image -->
                      <div class="blog-one__content text-center">
                          <div class="blog-one__meta">
                              <a data-toggle="tooltip" data-placement="top" title="Posted On Jan 19" href="#"><i class="fa fa-calendar-alt"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="No Comments" href="#"><i class="fa fa-comments"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="Posted By Admin" href="#"><i class="fa fa-user"></i></a>
                          </div><!-- /.blog-one__meta -->
                          <h2 class="blog-one__title"><a href="/news-details">Get a tips to develop a quality
                                  education</a>
                          </h2><!-- /.blog-one__title -->
                          <p class="blog-one__text">Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit
                              amet finibus eros.</p><!-- /.blog-one__text -->
                          <a href="/news-details" class="blog-one__link">Read More</a><!-- /.blog-one__link -->
                      </div><!-- /.blog-one__content -->
                  </div><!-- /.blog-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4">
                  <div class="blog-one__single">
                      <div class="blog-one__image">
                          <img src="/assets/images/blog-1-3.jpg" alt="">
                          <a class="blog-one__plus" href="/news-details"><i class="kipso-icon-plus-symbol"></i>
                              <!-- /.kipso-icon-plus-symbol --></a>
                      </div><!-- /.blog-one__image -->
                      <div class="blog-one__content text-center">
                          <div class="blog-one__meta">
                              <a data-toggle="tooltip" data-placement="top" title="Posted On Jan 19" href="#"><i class="fa fa-calendar-alt"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="No Comments" href="#"><i class="fa fa-comments"></i></a>
                              <a data-toggle="tooltip" data-placement="top" title="Posted By Admin" href="#"><i class="fa fa-user"></i></a>
                          </div><!-- /.blog-one__meta -->
                          <h2 class="blog-one__title"><a href="/news-details">Learn variety of programs and
                                  courses</a>
                          </h2><!-- /.blog-one__title -->
                          <p class="blog-one__text">Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit
                              amet finibus eros.</p><!-- /.blog-one__text -->
                          <a href="/news-details" class="blog-one__link">Read More</a><!-- /.blog-one__link -->
                      </div><!-- /.blog-one__content -->
                  </div><!-- /.blog-one__single -->
              </div><!-- /.col-lg-4 -->
          </div><!-- /.row -->

      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "BlogHome"
    }
</script>

<style scoped>

</style>
