<template>
  <section class="about-one " style="background-color: rgb(242,242,242);">
      <img src="/assets/images/circle-stripe.png" class="about-one__circle" alt="">
      <div class="container ">
         
         <div class="row justify-content-between">
                 
                  <div class="col-lg-4">
                      
                      <div class="card">
                        <div class="card-body">
                             <div class="block-title2 text-center">
                            <h2 class="block-title__title2">Education & STEM <br>
                                </h2><!-- /.block-title__title -->
                        </div><!-- /.block-title -->
                           <div class="text-left">
                            <p>
                                Emerging markets present significant opportunity as well as risks.  One proven means to reduce risk while developing a commercial presence is by working through International Financial Institutions (IFIs). IFI funded projects, across nearly all sectors, rely on private sector participation to deliver project outcomes and stimulate private sector-led growth.
                             </p>
                           </div>

                           <div class="text-left">
                               <p>
                                   Founded 28 years ago, DFI has delivered more than $3 B in contracts and funding across diverse sectors while providing 30-100X ROI for our long-standing clients.  We are active in Africa, Asia, Latin America, and CEE/CIS, DFI’s team of multidisciplinary experts is dedicated to driving business growth and achieving results.
                               </p>
                           </div>
                        </div>
                        </div>
                  </div><!-- /.col-lg-6 -->
                   <div class="col-lg-8">
                      <div class="team-details__content" style="padding-top:10px">
                          <h5 class="team-details__title2"> We deliver near and longer-term qualified funded sales pipeline, brand positioning, prioritized joint pursuit and capture efforts.
                         </h5> <!-- /.team-details__title -->
                          
                          <h4 class="team-details__title3"> Qualified Sales Pipeline </h4>
                          <p class="team-details__text">Lorem Ipsum is simply dummy text of the printing and type industry.
                              Lorem Ipsum has been the standard dummy text ever since the when an unknown was popularised. It
                              has survived not only five centuries, but also the leap into electronic typesetting remaining
                              unchanged.</p><!-- /.team-details__text -->
                              <br>
                               <h4 class="team-details__title3"> Partner Identification </h4>
                              <p class="team-details__text">Lorem Ipsum is simply dummy text of the printing and type industry.
                              Lorem Ipsum has been the standard dummy text ever since the when an unknown was popularised. It
                              has survived not only five centuries, but also the leap into electronic typesetting remaining
                              unchanged </p> <br>
                               <h4 class="team-details__title3"> Market Assessment and Sales Pursuit Strategy </h4>
                              <p class="team-details__text">
                                  Unique expertise. DFI brings a distinct perspective to emerging market challenges and solutions – namely international financial institution (IFI) expertise.  Our long, successful experience navigating the operational, policy, and procurement complexities of the IFIs and other development stakeholders informs our client relationships.  Whether clients require market entry, sales development, risk mitigation, sustainable supply chain or social impact, our dedicated client team leverages the IFIs to accelerate client objectives.
                              </p>
                          
                      </div><!-- /.team-details__content -->
                  </div><!-- /.col-lg-6 -->
              </div><!-- /.row -->
      </div><!-- /.container -->

      
  </section>
  
</template>

<script>
    export default {
        name: "AboutOne"
    }
</script>

<style scoped>

.block-title__title2 {
    margin: 0;
    color: #012237;
    font-size: 40px;
    font-weight: bold;
   
}
.block-title2{

    padding-bottom: 10px;
}

.team-details__title2 {
    margin: 0;
    color: rgb(26,74,145);
    
    margin-bottom: 30px;
}

.team-details__title3 {
    margin: 0;
    color: rgb(26,74,145);
    
    margin-bottom: 20px;
}

.team-details__text {
    margin: 0;
    color: #81868a;
    font-size: 16px;
    line-height: 34px;
    font-weight: 500;
}

</style>
