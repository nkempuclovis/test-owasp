<template>
  <section class="course-category-three">
      <img src="/assets/images/circle-stripe.png" class="course-category-three__circle" alt="">
      <div class="container">
          <div class="block-title">
              <h2 class="block-title__title">Browse online <br>
                  course categories</h2><!-- /.block-title__title -->
          </div><!-- /.block-title -->
          <div class="row">
              <div class="col-lg-3 col-md-6 col-sm-12">
                  <div class="course-category-three__single">
                      <img src="/assets/images/course-category-1-1.png" alt="">
                      <div class="course-category-three__content">
                          <h3 class="course-category-three__title"><a href="#">IT & Software </a></h3>
                          <!-- /.course-category-three__title -->
                          <p class="course-category-three__text">Over 752 Courses</p>
                          <!-- /.course-category-three__text -->
                      </div><!-- /.course-category-three__content -->
                  </div><!-- /.course-category-three__single -->
              </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
              <div class="col-lg-3 col-md-6 col-sm-12">
                  <div class="course-category-three__single">
                      <img src="/assets/images/course-category-1-2.png" alt="">
                      <div class="course-category-three__content">
                          <h3 class="course-category-three__title"><a href="#">Development </a></h3>
                          <!-- /.course-category-three__title -->
                          <p class="course-category-three__text">Over 752 Courses</p>
                          <!-- /.course-category-three__text -->
                      </div><!-- /.course-category-three__content -->
                  </div><!-- /.course-category-three__single -->
              </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
              <div class="col-lg-3 col-md-6 col-sm-12">
                  <div class="course-category-three__single">
                      <img src="/assets/images/course-category-1-3.png" alt="">
                      <div class="course-category-three__content">
                          <h3 class="course-category-three__title"><a href="#">Photography</a></h3>
                          <!-- /.course-category-three__title -->
                          <p class="course-category-three__text">Over 752 Courses</p>
                          <!-- /.course-category-three__text -->
                      </div><!-- /.course-category-three__content -->
                  </div><!-- /.course-category-three__single -->
              </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
              <div class="col-lg-3 col-md-6 col-sm-12">
                  <div class="course-category-three__single">
                      <img src="/assets/images/course-category-1-4.png" alt="">
                      <div class="course-category-three__content">
                          <h3 class="course-category-three__title"><a href="#">Marketing</a></h3>
                          <!-- /.course-category-three__title -->
                          <p class="course-category-three__text">Over 752 Courses</p>
                          <!-- /.course-category-three__text -->
                      </div><!-- /.course-category-three__content -->
                  </div><!-- /.course-category-three__single -->
              </div><!-- /.col-lg-3 col-md-6 col-sm-12 -->
          </div><!-- /.row -->
          <div class="text-center">
              <a href="#" class="thm-btn course-category-three__more-link">View All Categories</a><!-- /.thm-btn -->
          </div><!-- /.text-center -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "CourseCatThree"
    }
</script>

<style scoped>

</style>
