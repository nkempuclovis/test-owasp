<template>
  <section class="cta-one cta-one__home-one" :style="{backgroundImage: `url(/assets/images/banner3.jpg)`}">
        <div class="container">
            <h2 class="cta-one__title">ADFG Bringing  <br>
                Inovation & Development <br>
                Closer To The Continent</h2><!-- /.cta-one__title -->
            <div class="cta-one__btn-block">
                <a href="#" class="thm-btn cta-one__btn">Learn More</a><!-- /.thm-btn -->
            </div><!-- /.cta-one__btn-block -->
        </div><!-- /.container -->
    </section>
</template>

<script>
    export default {
        name: "CallToActionOne"
    }
</script>

<style scoped>

</style>
