<template>
<section class="course-one course-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="course-one__single">
                    <div class="course-one__image">
                        <img src="/assets/images/course-1-1.jpg" alt="">
                        <i class="far fa-heart"></i><!-- /.far fa-heart -->
                    </div><!-- /.course-one__image -->
                    <div class="course-one__content">
                        <a href="#" class="course-one__category">development</a><!-- /.course-one__category -->
                        <div class="course-one__admin">
                            <img src="/assets/images/team-1-1.jpg" alt="">
                            by <nuxt-link to="/teacher-details">Lou Guerrero</nuxt-link>
                        </div><!-- /.course-one__admin -->
                        <h2 class="course-one__title"><nuxt-link to="/course-details">New react bootcamp</nuxt-link></h2>
                        <!-- /.course-one__title -->
                        <div class="course-one__stars">
                            <span class="course-one__stars-wrap">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </span><!-- /.course-one__stars-wrap -->
                            <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                            <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                        </div><!-- /.course-one__stars -->
                        <div class="course-one__meta">
                            <nuxt-link to="/course-details"><i class="far fa-clock"></i> 10 Hours</nuxt-link>
                            <nuxt-link to="/course-details"><i class="far fa-folder-open"></i> 6 Lectures</nuxt-link>
                            <nuxt-link to="/course-details">$18</nuxt-link>
                        </div><!-- /.course-one__meta -->
                        <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                    </div><!-- /.course-one__content -->
                </div><!-- /.course-one__single -->
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
                <div class="course-one__single">
                    <div class="course-one__image">
                        <img src="/assets/images/course-1-2.jpg" alt="">
                        <i class="far fa-heart"></i><!-- /.far fa-heart -->
                    </div><!-- /.course-one__image -->
                    <div class="course-one__content">
                        <a href="#" class="course-one__category">It &amp; Software</a><!-- /.course-one__category -->
                        <div class="course-one__admin">
                            <img src="/assets/images/team-1-2.jpg" alt="">
                            by <nuxt-link to="/teacher-details">Cora Diaz</nuxt-link>
                        </div><!-- /.course-one__admin -->
                        <h2 class="course-one__title"><nuxt-link to="/course-details">Improve editing skills</nuxt-link></h2>
                        <!-- /.course-one__title -->
                        <div class="course-one__stars">
                            <span class="course-one__stars-wrap">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </span><!-- /.course-one__stars-wrap -->
                            <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                            <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                        </div><!-- /.course-one__stars -->
                        <div class="course-one__meta">
                            <nuxt-link to="/course-details"><i class="far fa-clock"></i> 10 Hours</nuxt-link>
                            <nuxt-link to="/course-details"><i class="far fa-folder-open"></i> 6 Lectures</nuxt-link>
                            <nuxt-link to="/course-details">$18</nuxt-link>
                        </div><!-- /.course-one__meta -->
                        <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                    </div><!-- /.course-one__content -->
                </div><!-- /.course-one__single -->
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
                <div class="course-one__single">
                    <div class="course-one__image">
                        <img src="/assets/images/course-1-3.jpg" alt="">
                        <i class="far fa-heart"></i><!-- /.far fa-heart -->
                    </div><!-- /.course-one__image -->
                    <div class="course-one__content">
                        <a href="#" class="course-one__category">marketing</a><!-- /.course-one__category -->
                        <div class="course-one__admin">
                            <img src="/assets/images/team-1-3.jpg" alt="">
                            by <nuxt-link to="/teacher-details">Ruth Becker</nuxt-link>
                        </div><!-- /.course-one__admin -->
                        <h2 class="course-one__title"><nuxt-link to="/course-details">Marketing strategies</nuxt-link></h2>
                        <!-- /.course-one__title -->
                        <div class="course-one__stars">
                            <span class="course-one__stars-wrap">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </span><!-- /.course-one__stars-wrap -->
                            <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                            <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                        </div><!-- /.course-one__stars -->
                        <div class="course-one__meta">
                            <nuxt-link to="/course-details"><i class="far fa-clock"></i> 10 Hours</nuxt-link>
                            <nuxt-link to="/course-details"><i class="far fa-folder-open"></i> 6 Lectures</nuxt-link>
                            <nuxt-link to="/course-details">$18</nuxt-link>
                        </div><!-- /.course-one__meta -->
                        <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                    </div><!-- /.course-one__content -->
                </div><!-- /.course-one__single -->
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
                <div class="course-one__single">
                    <div class="course-one__image">
                        <img src="/assets/images/course-1-4.jpg" alt="">
                        <i class="far fa-heart"></i><!-- /.far fa-heart -->
                    </div><!-- /.course-one__image -->
                    <div class="course-one__content">
                        <a href="#" class="course-one__category">Photography</a><!-- /.course-one__category -->
                        <div class="course-one__admin">
                            <img src="/assets/images/team-1-4.jpg" alt="">
                            by <nuxt-link to="/teacher-details">Ernest Rodriquez</nuxt-link>
                        </div><!-- /.course-one__admin -->
                        <h2 class="course-one__title"><nuxt-link to="/course-details">Basics of photography</nuxt-link></h2>
                        <!-- /.course-one__title -->
                        <div class="course-one__stars">
                            <span class="course-one__stars-wrap">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </span><!-- /.course-one__stars-wrap -->
                            <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                            <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                        </div><!-- /.course-one__stars -->
                        <div class="course-one__meta">
                            <nuxt-link to="/course-details"><i class="far fa-clock"></i> 10 Hours</nuxt-link>
                            <nuxt-link to="/course-details"><i class="far fa-folder-open"></i> 6 Lectures</nuxt-link>
                            <nuxt-link to="/course-details">$18</nuxt-link>
                        </div><!-- /.course-one__meta -->
                        <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                    </div><!-- /.course-one__content -->
                </div><!-- /.course-one__single -->
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
                <div class="course-one__single">
                    <div class="course-one__image">
                        <img src="/assets/images/course-1-5.jpg" alt="">
                        <i class="far fa-heart"></i><!-- /.far fa-heart -->
                    </div><!-- /.course-one__image -->
                    <div class="course-one__content">
                        <a href="#" class="course-one__category">marketing</a><!-- /.course-one__category -->
                        <div class="course-one__admin">
                            <img src="/assets/images/team-1-5.jpg" alt="">
                            by <nuxt-link to="/teacher-details">Isabella Stanley</nuxt-link>
                        </div><!-- /.course-one__admin -->
                        <h2 class="course-one__title"><nuxt-link to="/course-details">Affiliate bootcamp</nuxt-link>
                        </h2>
                        <!-- /.course-one__title -->
                        <div class="course-one__stars">
                            <span class="course-one__stars-wrap">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </span><!-- /.course-one__stars-wrap -->
                            <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                            <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                        </div><!-- /.course-one__stars -->
                        <div class="course-one__meta">
                            <nuxt-link to="/course-details"><i class="far fa-clock"></i> 10 Hours</nuxt-link>
                            <nuxt-link to="/course-details"><i class="far fa-folder-open"></i> 6 Lectures</nuxt-link>
                            <nuxt-link to="/course-details">$18</nuxt-link>
                        </div><!-- /.course-one__meta -->
                        <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                    </div><!-- /.course-one__content -->
                </div><!-- /.course-one__single -->
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
                <div class="course-one__single">
                    <div class="course-one__image">
                        <img src="/assets/images/course-1-6.jpg" alt="">
                        <i class="far fa-heart"></i><!-- /.far fa-heart -->
                    </div><!-- /.course-one__image -->
                    <div class="course-one__content">
                        <a href="#" class="course-one__category">Health &amp; Fitness</a><!-- /.course-one__category -->
                        <div class="course-one__admin">
                            <img src="/assets/images/team-1-6.jpg" alt="">
                            by <nuxt-link to="/teacher-details">Katherine Collins</nuxt-link>
                        </div><!-- /.course-one__admin -->
                        <h2 class="course-one__title"><nuxt-link to="/course-details">Healthy workout tips </nuxt-link></h2>
                        <!-- /.course-one__title -->
                        <div class="course-one__stars">
                            <span class="course-one__stars-wrap">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </span><!-- /.course-one__stars-wrap -->
                            <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                            <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                        </div><!-- /.course-one__stars -->
                        <div class="course-one__meta">
                            <nuxt-link to="/course-details"><i class="far fa-clock"></i> 10 Hours</nuxt-link>
                            <nuxt-link to="/course-details"><i class="far fa-folder-open"></i> 6 Lectures</nuxt-link>
                            <nuxt-link to="/course-details">$18</nuxt-link>
                        </div><!-- /.course-one__meta -->
                        <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                    </div><!-- /.course-one__content -->
                </div><!-- /.course-one__single -->
            </div><!-- /.col-lg-4 -->
        </div><!-- /.row -->
        <div class="post-pagination">
            <a href="#"><i class="fa fa-angle-double-left"></i><!-- /.fa fa-angle-double-left --></a>
            <a class="active" href="#">1</a>
            <a href="#">2</a>
            <a href="#">3</a>
            <a href="#">4</a>
            <a href="#"><i class="fa fa-angle-double-right"></i><!-- /.fa fa-angle-double-left --></a>
        </div><!-- /.post-pagination -->

    </div><!-- /.container -->
</section>
</template>

<script>
    export default {
        name: "Course"
    }
</script>

<style scoped>

</style>
