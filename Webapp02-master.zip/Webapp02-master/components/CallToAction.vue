<template>
  <section class="cta-one">
      <div class="container">
          <h2 class="cta-one__title">Fill form for free to regitser <br>
              yourself now</h2><!-- /.cta-one__title -->
          <div class="cta-one__btn-block">
              <a href="#" class="thm-btn cta-one__btn">Start Learning Now</a><!-- /.thm-btn -->
          </div><!-- /.cta-one__btn-block -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "CallToAction"
    }
</script>

<style scoped>

</style>
