<template>
  <section class="team-one team-page">
      <div class="container">
          <div class="row">
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                  <div class="team-one__single">
                      <div class="team-one__image">
                          <img src="/assets/images/team-1-1.jpg" alt="">
                      </div><!-- /.team-one__image -->
                      <div class="team-one__content">
                          <h2 class="team-one__name"><nuxt-link to="/teacher-details">Adelaide Hunter</nuxt-link></h2>
                          <!-- /.team-one__name -->
                          <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                          <p class="team-one__text">There are many varia of passages of lorem.</p>
                          <!-- /.team-one__text -->
                      </div><!-- /.team-one__content -->
                      <div class="team-one__social">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                          <a href="#"><i class="fab fa-facebook-square"></i></a>
                          <a href="#"><i class="fab fa-pinterest-p"></i></a>
                          <a href="#"><i class="fab fa-instagram"></i></a>
                      </div><!-- /.team-one__social -->
                  </div><!-- /.team-one__single -->
              </div><!-- /.col-lg-3 -->
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                  <div class="team-one__single">
                      <div class="team-one__image">
                          <img src="/assets/images/team-1-2.jpg" alt="">
                      </div><!-- /.team-one__image -->
                      <div class="team-one__content">
                          <h2 class="team-one__name"><nuxt-link to="/teacher-details">Christina Newman</nuxt-link></h2>
                          <!-- /.team-one__name -->
                          <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                          <p class="team-one__text">There are many varia of passages of lorem.</p>
                          <!-- /.team-one__text -->
                      </div><!-- /.team-one__content -->
                      <div class="team-one__social">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                          <a href="#"><i class="fab fa-facebook-square"></i></a>
                          <a href="#"><i class="fab fa-pinterest-p"></i></a>
                          <a href="#"><i class="fab fa-instagram"></i></a>
                      </div><!-- /.team-one__social -->
                  </div><!-- /.team-one__single -->
              </div><!-- /.col-lg-3 -->
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                  <div class="team-one__single">
                      <div class="team-one__image">
                          <img src="/assets/images/team-1-3.jpg" alt="">
                      </div><!-- /.team-one__image -->
                      <div class="team-one__content">
                          <h2 class="team-one__name"><nuxt-link to="/teacher-details">Gilbert Daniels</nuxt-link></h2>
                          <!-- /.team-one__name -->
                          <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                          <p class="team-one__text">There are many varia of passages of lorem.</p>
                          <!-- /.team-one__text -->
                      </div><!-- /.team-one__content -->
                      <div class="team-one__social">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                          <a href="#"><i class="fab fa-facebook-square"></i></a>
                          <a href="#"><i class="fab fa-pinterest-p"></i></a>
                          <a href="#"><i class="fab fa-instagram"></i></a>
                      </div><!-- /.team-one__social -->
                  </div><!-- /.team-one__single -->
              </div><!-- /.col-lg-3 -->
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                  <div class="team-one__single">
                      <div class="team-one__image">
                          <img src="/assets/images/team-1-4.jpg" alt="">
                      </div><!-- /.team-one__image -->
                      <div class="team-one__content">
                          <h2 class="team-one__name"><nuxt-link to="/teacher-details">Austin Caldwell</nuxt-link></h2>
                          <!-- /.team-one__name -->
                          <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                          <p class="team-one__text">There are many varia of passages of lorem.</p>
                          <!-- /.team-one__text -->
                      </div><!-- /.team-one__content -->
                      <div class="team-one__social">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                          <a href="#"><i class="fab fa-facebook-square"></i></a>
                          <a href="#"><i class="fab fa-pinterest-p"></i></a>
                          <a href="#"><i class="fab fa-instagram"></i></a>
                      </div><!-- /.team-one__social -->
                  </div><!-- /.team-one__single -->
              </div><!-- /.col-lg-3 -->
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                  <div class="team-one__single">
                      <div class="team-one__image">
                          <img src="/assets/images/team-1-5.jpg" alt="">
                      </div><!-- /.team-one__image -->
                      <div class="team-one__content">
                          <h2 class="team-one__name"><nuxt-link to="/teacher-details">Phoebe Park</nuxt-link></h2>
                          <!-- /.team-one__name -->
                          <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                          <p class="team-one__text">There are many varia of passages of lorem.</p>
                          <!-- /.team-one__text -->
                      </div><!-- /.team-one__content -->
                      <div class="team-one__social">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                          <a href="#"><i class="fab fa-facebook-square"></i></a>
                          <a href="#"><i class="fab fa-pinterest-p"></i></a>
                          <a href="#"><i class="fab fa-instagram"></i></a>
                      </div><!-- /.team-one__social -->
                  </div><!-- /.team-one__single -->
              </div><!-- /.col-lg-3 -->
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                  <div class="team-one__single">
                      <div class="team-one__image">
                          <img src="/assets/images/team-1-6.jpg" alt="">
                      </div><!-- /.team-one__image -->
                      <div class="team-one__content">
                          <h2 class="team-one__name"><nuxt-link to="/teacher-details">Matilda Hawkins</nuxt-link></h2>
                          <!-- /.team-one__name -->
                          <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                          <p class="team-one__text">There are many varia of passages of lorem.</p>
                          <!-- /.team-one__text -->
                      </div><!-- /.team-one__content -->
                      <div class="team-one__social">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                          <a href="#"><i class="fab fa-facebook-square"></i></a>
                          <a href="#"><i class="fab fa-pinterest-p"></i></a>
                          <a href="#"><i class="fab fa-instagram"></i></a>
                      </div><!-- /.team-one__social -->
                  </div><!-- /.team-one__single -->
              </div><!-- /.col-lg-3 -->
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                  <div class="team-one__single">
                      <div class="team-one__image">
                          <img src="/assets/images/team-1-7.jpg" alt="">
                      </div><!-- /.team-one__image -->
                      <div class="team-one__content">
                          <h2 class="team-one__name"><nuxt-link to="/teacher-details">Lizzie Butler</nuxt-link></h2>
                          <!-- /.team-one__name -->
                          <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                          <p class="team-one__text">There are many varia of passages of lorem.</p>
                          <!-- /.team-one__text -->
                      </div><!-- /.team-one__content -->
                      <div class="team-one__social">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                          <a href="#"><i class="fab fa-facebook-square"></i></a>
                          <a href="#"><i class="fab fa-pinterest-p"></i></a>
                          <a href="#"><i class="fab fa-instagram"></i></a>
                      </div><!-- /.team-one__social -->
                  </div><!-- /.team-one__single -->
              </div><!-- /.col-lg-3 -->
              <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                  <div class="team-one__single">
                      <div class="team-one__image">
                          <img src="/assets/images/team-1-8.jpg" alt="">
                      </div><!-- /.team-one__image -->
                      <div class="team-one__content">
                          <h2 class="team-one__name"><nuxt-link to="/teacher-details">Trevor Turner</nuxt-link></h2>
                          <!-- /.team-one__name -->
                          <p class="team-one__designation">Teacher</p><!-- /.team-one__designation -->
                          <p class="team-one__text">There are many varia of passages of lorem.</p>
                          <!-- /.team-one__text -->
                      </div><!-- /.team-one__content -->
                      <div class="team-one__social">
                          <a href="#"><i class="fab fa-twitter"></i></a>
                          <a href="#"><i class="fab fa-facebook-square"></i></a>
                          <a href="#"><i class="fab fa-pinterest-p"></i></a>
                          <a href="#"><i class="fab fa-instagram"></i></a>
                      </div><!-- /.team-one__social -->
                  </div><!-- /.team-one__single -->
              </div><!-- /.col-lg-3 -->
          </div><!-- /.row -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "Teachers"
    }
</script>

<style scoped>

</style>
