<template>
  <section class="become-teacher">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="become-teacher__content">
                    <h2 class="become-teacher__title">Teaching benefits</h2><!-- /.become-teacher__title -->
                    <p class="become-teacher__text">Lorem Ipsum is simply dummy text of the printing and type industry.
                        Lorem Ipsum has been the standard dummy text ever since the when an unknown was popularised. It
                        has survived not only five centuries, but also the leap into electronic typesetting remaining
                        unchanged.</p><!-- /.become-teacher__text -->
                    <h2 class="become-teacher__subtitle">Health and Pension</h2><!-- /.become-teacher__subtitle -->
                    <p class="become-teacher__text">Lorem Ipsum has been the standard dummy text ever since the when an
                        unknown was popularised. It has survived not only five centuries. but also the leap into
                        electronic typesetting remaining unchanged.</p><!-- /.become-teacher__text -->
                    <h2 class="become-teacher__subtitle">Vacation Time</h2><!-- /.become-teacher__subtitle -->
                    <p class="become-teacher__text">Lorem Ipsum has been the standard dummy text ever since the when an
                        unknown was popularised. It has survived not only five centuries. but also the leap into
                        electronic typesetting remaining unchanged.</p><!-- /.become-teacher__text -->
                </div><!-- /.become-teacher__content -->
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
                <div class="become-teacher__form">
                    <div class="become-teacher__form-top">
                        <h2 class="become-teacher__form-title">
                            Apply for teaching
                        </h2><!-- /.become-teacher__form-title -->
                    </div><!-- /.become-teacher__top -->
                    <form action="#" class="become-teacher__form-content contact-form-validated" novalidate="novalidate">
                        <input type="text" placeholder="Your Name" name="name">
                        <input type="text" placeholder="Email Address" name="email">
                        <input type="text" placeholder="Phone Number" name="phone">
                        <input type="text" placeholder="Comment" name="message">
                        <button type="submit" class="thm-btn become-teacher__form-btn">Apply For It</button>
                    </form><!-- /.become-teacher__form-content -->
                    <div class="result text-center"></div><!-- /.result -->
                </div><!-- /.become-teacher__form -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section>
</template>

<script>
    export default {
        name: "BecomeTeacher"
    }
</script>

<style scoped>

</style>
