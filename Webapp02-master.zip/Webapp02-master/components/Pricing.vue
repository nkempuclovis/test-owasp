<template>
  <section class="pricing-one pricing-page ">
        <div class="container">
            <div class="block-title text-center">
                <h2 class="block-title__title">Choose the right <br>
                    plan for you</h2><!-- /.block-title__title -->
            </div><!-- /.block-title -->
            <div class="row">
                <div class="col-lg-4">
                    <div class="pricing-one__single">
                        <div class="pricing-one__inner">
                            <h2 class="pricing-one__price">$20.00 </h2><!-- /.pricing-one__price -->
                            <p class="pricing-one__name">basic pack</p><!-- /.pricing-one__name -->
                            <ul class="pricing-one__list list-unstyled">
                                <li>3 Full Courses</li>
                                <li>Lifetime free support</li>
                                <li>Upgrate options</li>
                                <li>9 Days Time</li>
                            </ul><!-- /.pricing-one__list -->
                            <a href="#" class="thm-btn pricing-one__btn">Choose Plan</a><!-- /.thm-btn -->
                            <p class="pricing-one__tag-line">No hidden charges!</p><!-- /.pricing-one__tag-line -->
                        </div><!-- /.pricing-one__inner -->
                    </div><!-- /.pricing-one__single -->
                </div><!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="pricing-one__single">
                        <div class="pricing-one__inner">
                            <h2 class="pricing-one__price">$30.00 </h2><!-- /.pricing-one__price -->
                            <p class="pricing-one__name">medium pack</p><!-- /.pricing-one__name -->
                            <ul class="pricing-one__list list-unstyled">
                                <li>3 Full Courses</li>
                                <li>Lifetime free support</li>
                                <li>Upgrate options</li>
                                <li>9 Days Time</li>
                            </ul><!-- /.pricing-one__list -->
                            <a href="#" class="thm-btn pricing-one__btn">Choose Plan</a><!-- /.thm-btn -->
                            <p class="pricing-one__tag-line">No hidden charges!</p><!-- /.pricing-one__tag-line -->
                        </div><!-- /.pricing-one__inner -->
                    </div><!-- /.pricing-one__single -->
                </div><!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <div class="pricing-one__single">
                        <div class="pricing-one__inner">
                            <h2 class="pricing-one__price">$40.00 </h2><!-- /.pricing-one__price -->
                            <p class="pricing-one__name">premium pack</p><!-- /.pricing-one__name -->
                            <ul class="pricing-one__list list-unstyled">
                                <li>3 Full Courses</li>
                                <li>Lifetime free support</li>
                                <li>Upgrate options</li>
                                <li>9 Days Time</li>
                            </ul><!-- /.pricing-one__list -->
                            <a href="#" class="thm-btn pricing-one__btn">Choose Plan</a><!-- /.thm-btn -->
                            <p class="pricing-one__tag-line">No hidden charges!</p><!-- /.pricing-one__tag-line -->
                        </div><!-- /.pricing-one__inner -->
                    </div><!-- /.pricing-one__single -->
                </div><!-- /.col-lg-4 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>
</template>

<script>
    export default {
        name: "Pricing"
    }
</script>

<style scoped>

</style>
