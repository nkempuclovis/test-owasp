<template>
    <div>
      <section class="team-details">
          <div class="container">
              <div class="row justify-content-between">
                 
                  <div class="col-lg-4">
                      <div class="team-one__single">
                          <div class="team-one__image">
                              <img src="/assets/images/africaman.jpg" alt="">
                          </div><!-- /.team-one__image -->
                          <div class="team-one__content">
                              <h2 class="team-one__name"><a href="team-details.html">Adelaide Hunter</a></h2>
                              <!-- /.team-one__name -->
                              <p class="team-one__designation">C.E.O</p><!-- /.team-one__designation -->

                          </div><!-- /.team-one__content -->
                          <div class="team-one__social">
                              <a href="#"><i class="fab fa-twitter"></i></a>
                              <a href="#"><i class="fab fa-facebook-square"></i></a>
                              <a href="#"><i class="fab fa-pinterest-p"></i></a>
                              <a href="#"><i class="fab fa-instagram"></i></a>
                          </div><!-- /.team-one__social -->
                      </div><!-- /.team-one__single -->
                  </div><!-- /.col-lg-6 -->
                   <div class="col-lg-7">
                      <div class="team-details__content">
                          <h2 class="team-details__title">Adelaide Hunter</h2><!-- /.team-details__title -->
                          <p class="team-details__text">Lorem Ipsum is simply dummy text of the printing and type industry.
                              Lorem Ipsum has been the standard dummy text ever since the when an unknown was popularised. It
                              has survived not only five centuries, but also the leap into electronic typesetting remaining
                              unchanged.</p><!-- /.team-details__text -->
                              <br>
                              <p>Lorem Ipsum is simply dummy text of the printing and type industry.
                              Lorem Ipsum has been the standard dummy text ever since the when an unknown was popularised. It
                              has survived not only five centuries, but also the leap into electronic typesetting remaining
                              unchanged </p>
                          
                      </div><!-- /.team-details__content -->
                  </div><!-- /.col-lg-6 -->
              </div><!-- /.row -->

               <div class="row justify-content-between" style="padding-top:60px">
                 
                  <div class="col-lg-4">
                      <div class="team-one__single">
                          <div class="team-one__image">
                              <img src="/assets/images/africaman.jpg" alt="">
                          </div><!-- /.team-one__image -->
                          <div class="team-one__content">
                              <h2 class="team-one__name"><a href="team-details.html">Adelaide Hunter</a></h2>
                              <!-- /.team-one__name -->
                              <p class="team-one__designation">C.E.O</p><!-- /.team-one__designation -->

                          </div><!-- /.team-one__content -->
                          <div class="team-one__social">
                              <a href="#"><i class="fab fa-twitter"></i></a>
                              <a href="#"><i class="fab fa-facebook-square"></i></a>
                              <a href="#"><i class="fab fa-pinterest-p"></i></a>
                              <a href="#"><i class="fab fa-instagram"></i></a>
                          </div><!-- /.team-one__social -->
                      </div><!-- /.team-one__single -->
                  </div><!-- /.col-lg-6 -->
                   <div class="col-lg-7">
                      <div class="team-details__content">
                          <h2 class="team-details__title">Adelaide Hunter</h2><!-- /.team-details__title -->
                          <p class="team-details__text">Lorem Ipsum is simply dummy text of the printing and type industry.
                              Lorem Ipsum has been the standard dummy text ever since the when an unknown was popularised. It
                              has survived not only five centuries, but also the leap into electronic typesetting remaining
                              unchanged.</p><!-- /.team-details__text -->
                              <br>
                              <p>Lorem Ipsum is simply dummy text of the printing and type industry.
                              Lorem Ipsum has been the standard dummy text ever since the when an unknown was popularised. It
                              has survived not only five centuries, but also the leap into electronic typesetting remaining
                              unchanged </p>
                          
                      </div><!-- /.team-details__content -->
                  </div><!-- /.col-lg-6 -->
              </div><!-- /.row -->
          </div><!-- /.container -->
      </section><!-- /.team-details -->
     

      
    </div>
</template>

<script>
    export default {
        name: "Global Leadership "
    }
</script>

<style scoped>

</style>
