<template>
  <section class="cta-six thm-gray-bg">
              <img src="/assets/images/line-stripe-2.png" class="cta-six__line" alt="">
              <div class="container-fluid clearfix">
                  <div class="cta-six__left">
                      <div class="cta-six__content">
                          <div class="block-title text-left">
                              <h2 class="block-title__title">Start online learning
                                  anything</h2><!-- /.block-title__title -->
                          </div><!-- /.block-title -->
                          <img src="/assets/images/fact-1-1.jpg" alt="">
                      </div><!-- /.cta-six__content -->
                  </div><!-- /.cta-six__left -->
                  <div class="cta-six__right">
                      <img src="/assets/images/fact-1-2.jpg" alt="">
                      <h2 class="cta-six__title">More than <span class="counter">7840</span> students are registered</h2>
                      <!-- /.cta-six__title -->
                  </div><!-- /.cta-six__right -->
              </div><!-- /.container-fluid -->
          </section>
</template>

<script>
    export default {
        name: "CallToActionSix"
    }
</script>

<style scoped>

</style>
