<template>
  <section class="video-one">
      <div class="container">
          <img src="/assets/images/scratch-1-1.png" class="video-one__scratch" alt="">
          <div class="row">
              <div class="col-lg-6 d-flex align-items-end">
                  <div class="video-one__content">
                      <h2 class="video-one__title">Take a tour dolor <br>
                          sit amet, consect <br>
                          etur elit</h2><!-- /.video-one__title -->
                      <a href="#" class="thm-btn video-one__btn">Learn More</a><!-- /.thm-btn -->
                  </div><!-- /.video-one__content -->
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-6">
                  <div class="video-one__img">
                      <img src="/assets/images/video-1-1.jpg" alt="">
                      <a href="#" class="video-one__popup"><i class="fas fa-play"></i><!-- /.fas fa-play --></a>
                  </div><!-- /.video-one__img -->
              </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "VideoOne"
    }
</script>

<style scoped>

</style>
