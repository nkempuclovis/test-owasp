<template>
  <section class="cta-three">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 clearfix">
                <img src="/assets/images/cta-1.jpg" class="cta-three__image" alt="">
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6">
                <div class="cta-three__content">
                    <div class="block-title text-left">
                        <h2 class="block-title__title">Benefits of learning
                            with kipso</h2><!-- /.block-title__title -->
                    </div><!-- /.block-title -->
                    <p class="cta-three__text">There cursus massa at urnaaculis estie. Sed aliquamellus vitae ultrs
                        condmentum leo massa mollis estiegittis miristum nulla sed medy fringilla vitae.</p>
                    <!-- /.cta-three__text -->
                    <div class="cta-three__single-wrap">
                        <div class="cta-three__single">
                            <i class="kipso-icon-strategy"></i><!-- /.kipso-icon-strategy -->
                            <p class="cta-three__single-text">Professional
                                Courses</p><!-- /.cta-three__single-text -->
                        </div><!-- /.cta-three__single -->
                        <div class="cta-three__single">
                            <i class="kipso-icon-training"></i><!-- /.kipso-icon-training -->
                            <p class="cta-three__single-text">Live
                                Learning</p><!-- /.cta-three__single-text -->
                        </div><!-- /.cta-three__single -->
                        <div class="cta-three__single">
                            <i class="kipso-icon-human-resources"></i><!-- /.kipso-icon-human-resources -->
                            <p class="cta-three__single-text">Expert
                                Teachers</p><!-- /.cta-three__single-text -->
                        </div><!-- /.cta-three__single -->
                    </div><!-- /.cta-three__single-wrap -->
                    <a href="#" class="thm-btn">Learn More</a><!-- /.thm-btn -->
                </div><!-- /.cta-three__content -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section>
</template>

<script>
    export default {
        name: "CallToActionThree"
    }
</script>

<style scoped>

</style>
