<template>
    <div>
      <section class="course-one__top-title home-three">
                  <div class="container">
                      <div class="block-title">
                          <h2 class="block-title__title">Explore our <br>
                              popular courses</h2><!-- /.block-title__title -->
                      </div><!-- /.block-title -->
                  </div><!-- /.container -->
              </section><!-- /.course-one__top-title -->

      <section class="course-one home-three">
          <img src="assets/images/line-stripe.png" class="course-one__line" alt="">
          <div class="container">
              <div class="course-one__carousel owl-carousel owl-theme">
                  <div class="item">
                      <div class="course-one__single color-1">
                          <div class="course-one__image">
                              <img src="/assets/images/course-1-1.jpg" alt="">
                              <i class="far fa-heart"></i><!-- /.far fa-heart -->
                          </div><!-- /.course-one__image -->
                          <div class="course-one__content">
                              <a href="#" class="course-one__category">development</a><!-- /.course-one__category -->
                              <div class="course-one__admin">
                                  <img src="/assets/images/team-1-1.jpg" alt="">
                                  by <a href="teacher-details.html">Lou Guerrero</a>
                              </div><!-- /.course-one__admin -->
                              <h2 class="course-one__title"><a href="course-details.html">New react bootcamp</a></h2>
                              <!-- /.course-one__title -->
                              <div class="course-one__stars">
                                  <span class="course-one__stars-wrap">
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                  </span><!-- /.course-one__stars-wrap -->
                                  <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                  <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                              </div><!-- /.course-one__stars -->
                              <div class="course-one__meta">
                                  <a href="course-details.html"><i class="far fa-clock"></i> 10 Hours</a>
                                  <a href="course-details.html"><i class="far fa-folder-open"></i> 6 Lectures</a>
                                  <a href="course-details.html">$18</a>
                              </div><!-- /.course-one__meta -->
                              <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                          </div><!-- /.course-one__content -->
                      </div><!-- /.course-one__single -->
                  </div><!-- /.item -->
                  <div class="item">
                      <div class="course-one__single color-2">
                          <div class="course-one__image">
                              <img src="/assets/images/course-1-2.jpg" alt="">
                              <i class="far fa-heart"></i><!-- /.far fa-heart -->
                          </div><!-- /.course-one__image -->
                          <div class="course-one__content">
                              <a href="#" class="course-one__category">It & Software</a><!-- /.course-one__category -->
                              <div class="course-one__admin">
                                  <img src="/assets/images/team-1-2.jpg" alt="">
                                  by <a href="teacher-details.html">Cora Diaz</a>
                              </div><!-- /.course-one__admin -->
                              <h2 class="course-one__title"><a href="course-details.html">Improve editing skills</a></h2>
                              <!-- /.course-one__title -->
                              <div class="course-one__stars">
                                  <span class="course-one__stars-wrap">
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                  </span><!-- /.course-one__stars-wrap -->
                                  <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                  <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                              </div><!-- /.course-one__stars -->
                              <div class="course-one__meta">
                                  <a href="course-details.html"><i class="far fa-clock"></i> 10 Hours</a>
                                  <a href="course-details.html"><i class="far fa-folder-open"></i> 6 Lectures</a>
                                  <a href="course-details.html">$18</a>
                              </div><!-- /.course-one__meta -->
                              <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                          </div><!-- /.course-one__content -->
                      </div><!-- /.course-one__single -->
                  </div><!-- /.item -->
                  <div class="item">
                      <div class="course-one__single color-3">
                          <div class="course-one__image">
                              <img src="/assets/images/course-1-3.jpg" alt="">
                              <i class="far fa-heart"></i><!-- /.far fa-heart -->
                          </div><!-- /.course-one__image -->
                          <div class="course-one__content">
                              <a href="#" class="course-one__category">marketing</a><!-- /.course-one__category -->
                              <div class="course-one__admin">
                                  <img src="/assets/images/team-1-3.jpg" alt="">
                                  by <a href="teacher-details.html">Ruth Becker</a>
                              </div><!-- /.course-one__admin -->
                              <h2 class="course-one__title"><a href="course-details.html">Marketing strategies</a></h2>
                              <!-- /.course-one__title -->
                              <div class="course-one__stars">
                                  <span class="course-one__stars-wrap">
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                  </span><!-- /.course-one__stars-wrap -->
                                  <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                  <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                              </div><!-- /.course-one__stars -->
                              <div class="course-one__meta">
                                  <a href="course-details.html"><i class="far fa-clock"></i> 10 Hours</a>
                                  <a href="course-details.html"><i class="far fa-folder-open"></i> 6 Lectures</a>
                                  <a href="course-details.html">$18</a>
                              </div><!-- /.course-one__meta -->
                              <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                          </div><!-- /.course-one__content -->
                      </div><!-- /.course-one__single -->
                  </div><!-- /.item -->
                  <div class="item">
                      <div class="course-one__single color-4">
                          <div class="course-one__image">
                              <img src="/assets/images/course-1-4.jpg" alt="">
                              <i class="far fa-heart"></i><!-- /.far fa-heart -->
                          </div><!-- /.course-one__image -->
                          <div class="course-one__content">
                              <a href="#" class="course-one__category">Photography</a><!-- /.course-one__category -->
                              <div class="course-one__admin">
                                  <img src="/assets/images/team-1-4.jpg" alt="">
                                  by <a href="teacher-details.html">Ernest Rodriquez</a>
                              </div><!-- /.course-one__admin -->
                              <h2 class="course-one__title"><a href="course-details.html">Basics of photography</a></h2>
                              <!-- /.course-one__title -->
                              <div class="course-one__stars">
                                  <span class="course-one__stars-wrap">
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                  </span><!-- /.course-one__stars-wrap -->
                                  <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                  <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                              </div><!-- /.course-one__stars -->
                              <div class="course-one__meta">
                                  <a href="course-details.html"><i class="far fa-clock"></i> 10 Hours</a>
                                  <a href="course-details.html"><i class="far fa-folder-open"></i> 6 Lectures</a>
                                  <a href="course-details.html">$18</a>
                              </div><!-- /.course-one__meta -->
                              <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                          </div><!-- /.course-one__content -->
                      </div><!-- /.course-one__single -->
                  </div><!-- /.item -->
                  <div class="item">
                      <div class="course-one__single color-5">
                          <div class="course-one__image">
                              <img src="/assets/images/course-1-5.jpg" alt="">
                              <i class="far fa-heart"></i><!-- /.far fa-heart -->
                          </div><!-- /.course-one__image -->
                          <div class="course-one__content">
                              <a href="#" class="course-one__category">marketing</a><!-- /.course-one__category -->
                              <div class="course-one__admin">
                                  <img src="/assets/images/team-1-5.jpg" alt="">
                                  by <a href="teacher-details.html">Isabella Stanley</a>
                              </div><!-- /.course-one__admin -->
                              <h2 class="course-one__title"><a href="course-details.html">Affiliate bootcamp</a>
                              </h2>
                              <!-- /.course-one__title -->
                              <div class="course-one__stars">
                                  <span class="course-one__stars-wrap">
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                  </span><!-- /.course-one__stars-wrap -->
                                  <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                  <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                              </div><!-- /.course-one__stars -->
                              <div class="course-one__meta">
                                  <a href="course-details.html"><i class="far fa-clock"></i> 10 Hours</a>
                                  <a href="course-details.html"><i class="far fa-folder-open"></i> 6 Lectures</a>
                                  <a href="course-details.html">$18</a>
                              </div><!-- /.course-one__meta -->
                              <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                          </div><!-- /.course-one__content -->
                      </div><!-- /.course-one__single -->
                  </div><!-- /.item -->
                  <div class="item">
                      <div class="course-one__single color-6">
                          <div class="course-one__image">
                              <img src="/assets/images/course-1-6.jpg" alt="">
                              <i class="far fa-heart"></i><!-- /.far fa-heart -->
                          </div><!-- /.course-one__image -->
                          <div class="course-one__content">
                              <a href="#" class="course-one__category">Health & Fitness</a><!-- /.course-one__category -->
                              <div class="course-one__admin">
                                  <img src="/assets/images/team-1-6.jpg" alt="">
                                  by <a href="teacher-details.html">Katherine Collins</a>
                              </div><!-- /.course-one__admin -->
                              <h2 class="course-one__title"><a href="course-details.html">Healthy workout tips </a></h2>
                              <!-- /.course-one__title -->
                              <div class="course-one__stars">
                                  <span class="course-one__stars-wrap">
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                  </span><!-- /.course-one__stars-wrap -->
                                  <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                  <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                              </div><!-- /.course-one__stars -->
                              <div class="course-one__meta">
                                  <a href="course-details.html"><i class="far fa-clock"></i> 10 Hours</a>
                                  <a href="course-details.html"><i class="far fa-folder-open"></i> 6 Lectures</a>
                                  <a href="course-details.html">$18</a>
                              </div><!-- /.course-one__meta -->
                              <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                          </div><!-- /.course-one__content -->
                      </div><!-- /.course-one__single -->
                  </div><!-- /.item -->
                  <div class="item">
                      <div class="course-one__single color-1">
                          <div class="course-one__image">
                              <img src="/assets/images/course-1-1.jpg" alt="">
                              <i class="far fa-heart"></i><!-- /.far fa-heart -->
                          </div><!-- /.course-one__image -->
                          <div class="course-one__content">
                              <a href="#" class="course-one__category">development</a><!-- /.course-one__category -->
                              <div class="course-one__admin">
                                  <img src="/assets/images/team-1-1.jpg" alt="">
                                  by <a href="teacher-details.html">Lou Guerrero</a>
                              </div><!-- /.course-one__admin -->
                              <h2 class="course-one__title"><a href="course-details.html">New react bootcamp</a></h2>
                              <!-- /.course-one__title -->
                              <div class="course-one__stars">
                                  <span class="course-one__stars-wrap">
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                  </span><!-- /.course-one__stars-wrap -->
                                  <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                  <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                              </div><!-- /.course-one__stars -->
                              <div class="course-one__meta">
                                  <a href="course-details.html"><i class="far fa-clock"></i> 10 Hours</a>
                                  <a href="course-details.html"><i class="far fa-folder-open"></i> 6 Lectures</a>
                                  <a href="course-details.html">$18</a>
                              </div><!-- /.course-one__meta -->
                              <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                          </div><!-- /.course-one__content -->
                      </div><!-- /.course-one__single -->
                  </div><!-- /.item -->
                  <div class="item">
                      <div class="course-one__single color-2">
                          <div class="course-one__image">
                              <img src="/assets/images/course-1-2.jpg" alt="">
                              <i class="far fa-heart"></i><!-- /.far fa-heart -->
                          </div><!-- /.course-one__image -->
                          <div class="course-one__content">
                              <a href="#" class="course-one__category">It & Software</a><!-- /.course-one__category -->
                              <div class="course-one__admin">
                                  <img src="/assets/images/team-1-2.jpg" alt="">
                                  by <a href="teacher-details.html">Cora Diaz</a>
                              </div><!-- /.course-one__admin -->
                              <h2 class="course-one__title"><a href="course-details.html">Improve editing skills</a></h2>
                              <!-- /.course-one__title -->
                              <div class="course-one__stars">
                                  <span class="course-one__stars-wrap">
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                  </span><!-- /.course-one__stars-wrap -->
                                  <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                  <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                              </div><!-- /.course-one__stars -->
                              <div class="course-one__meta">
                                  <a href="course-details.html"><i class="far fa-clock"></i> 10 Hours</a>
                                  <a href="course-details.html"><i class="far fa-folder-open"></i> 6 Lectures</a>
                                  <a href="course-details.html">$18</a>
                              </div><!-- /.course-one__meta -->
                              <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                          </div><!-- /.course-one__content -->
                      </div><!-- /.course-one__single -->
                  </div><!-- /.item -->
                  <div class="item">
                      <div class="course-one__single color-3">
                          <div class="course-one__image">
                              <img src="/assets/images/course-1-3.jpg" alt="">
                              <i class="far fa-heart"></i><!-- /.far fa-heart -->
                          </div><!-- /.course-one__image -->
                          <div class="course-one__content">
                              <a href="#" class="course-one__category">marketing</a><!-- /.course-one__category -->
                              <div class="course-one__admin">
                                  <img src="/assets/images/team-1-3.jpg" alt="">
                                  by <a href="teacher-details.html">Ruth Becker</a>
                              </div><!-- /.course-one__admin -->
                              <h2 class="course-one__title"><a href="course-details.html">Marketing strategies</a></h2>
                              <!-- /.course-one__title -->
                              <div class="course-one__stars">
                                  <span class="course-one__stars-wrap">
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                      <i class="fa fa-star"></i>
                                  </span><!-- /.course-one__stars-wrap -->
                                  <span class="course-one__count">4.8</span><!-- /.course-one__count -->
                                  <span class="course-one__stars-count">250</span><!-- /.course-one__stars-count -->
                              </div><!-- /.course-one__stars -->
                              <div class="course-one__meta">
                                  <a href="course-details.html"><i class="far fa-clock"></i> 10 Hours</a>
                                  <a href="course-details.html"><i class="far fa-folder-open"></i> 6 Lectures</a>
                                  <a href="course-details.html">$18</a>
                              </div><!-- /.course-one__meta -->
                              <a href="#" class="course-one__link">See Preview</a><!-- /.course-one__link -->
                          </div><!-- /.course-one__content -->
                      </div><!-- /.course-one__single -->
                  </div><!-- /.item -->
              </div><!-- /.course-one__carousel -->
          </div><!-- /.container -->
      </section>

    </div>
</template>

<script>
    export default {
        name: "CourseThree"
    }
</script>

<style scoped>

</style>
