<template>
  <section class="course-category-two">
              <div class="container text-center">
                  <div class="inner-container">

                      <div class="course-category-two__carousel owl-carousel owl-theme">
                          <div class="item">
                              <div class="course-category-two__single color-1">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-desktop"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">IT & Software</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-2">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-web-programming"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Development</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-3">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-music-player"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Music</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-4">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-camera"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Photography</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-5">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-targeting"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Marketing</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-6">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-health"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Health & Fitness</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-1">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-desktop"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">IT & Software</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-2">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-web-programming"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Development</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-3">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-music-player"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Music</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-4">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-camera"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Photography</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-1">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-desktop"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">IT & Software</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-2">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-web-programming"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Development</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-3">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-music-player"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Music</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-4">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-camera"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Photography</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                          <div class="item">
                              <div class="course-category-two__single color-5">
                                  <div class="course-category-two__icon">
                                      <i class="kipso-icon-targeting"></i><!-- /.kipso-icon-camera -->
                                  </div><!-- /.course-category-two__icon -->
                                  <h3 class="course-category-two__title"><a href="#">Marketing</a></h3>
                                  <!-- /.course-category-two__title -->
                              </div><!-- /.course-category-two__single -->
                          </div><!-- /.item -->
                      </div><!-- /.course-category-two__carousel owl-carousel owl-theme -->
                  </div><!-- /.inner-container -->
              </div><!-- /.container -->
          </section>
</template>

<script>
    export default {
        name: "CourseCatTwo"
    }
</script>

<style scoped>

</style>
