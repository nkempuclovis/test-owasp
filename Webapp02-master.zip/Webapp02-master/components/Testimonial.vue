<template>
  <section class="testimonials-one testimonials-one__home-three">
      <div class="container">
          <div class="block-title text-center">
              <h2 class="block-title__title">What our students <br>
                  have to say</h2><!-- /.block-title__title -->
          </div><!-- /.block-title -->
          <div class="testimonials-one__carousel owl-carousel owl-theme">
              <div class="item">
                  <div class="testimonials-one__single">
                      <div class="testimonials-one__qoute">
                          <img src="/assets/images/qoute-1-1.png" alt="">
                      </div><!-- /.testimonials-one__qoute -->
                      <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                          the majority.</p><!-- /.testimonials-one__text -->
                      <img src="/assets/images/team-1-1.jpg" alt="" class="testimonials-one__img">
                      <h3 class="testimonials-one__name">Anne Hall</h3><!-- /.testimonials-one__name -->
                      <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                  </div><!-- /.testimonials-one__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="testimonials-one__single">
                      <div class="testimonials-one__qoute">
                          <img src="/assets/images/qoute-1-1.png" alt="">
                      </div><!-- /.testimonials-one__qoute -->
                      <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                          the majority have suffered alteration in some form.</p><!-- /.testimonials-one__text -->
                      <img src="/assets/images/team-1-2.jpg" alt="" class="testimonials-one__img">
                      <h3 class="testimonials-one__name">Andre Obrien</h3><!-- /.testimonials-one__name -->
                      <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                  </div><!-- /.testimonials-one__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="testimonials-one__single">
                      <div class="testimonials-one__qoute">
                          <img src="/assets/images/qoute-1-1.png" alt="">
                      </div><!-- /.testimonials-one__qoute -->
                      <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                          the majority have suffered alteration in some form, by injected humour.</p>
                      <!-- /.testimonials-one__text -->
                      <img src="/assets/images/team-1-3.jpg" alt="" class="testimonials-one__img">
                      <h3 class="testimonials-one__name">Shane Vasquez</h3><!-- /.testimonials-one__name -->
                      <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                  </div><!-- /.testimonials-one__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="testimonials-one__single">
                      <div class="testimonials-one__qoute">
                          <img src="/assets/images/qoute-1-1.png" alt="">
                      </div><!-- /.testimonials-one__qoute -->
                      <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                          the majority.</p><!-- /.testimonials-one__text -->
                      <img src="/assets/images/team-1-4.jpg" alt="" class="testimonials-one__img">
                      <h3 class="testimonials-one__name">Maud Lee</h3><!-- /.testimonials-one__name -->
                      <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                  </div><!-- /.testimonials-one__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="testimonials-one__single">
                      <div class="testimonials-one__qoute">
                          <img src="/assets/images/qoute-1-1.png" alt="">
                      </div><!-- /.testimonials-one__qoute -->
                      <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                          the majority have suffered alteration in some form.</p><!-- /.testimonials-one__text -->
                      <img src="/assets/images/team-1-5.jpg" alt="" class="testimonials-one__img">
                      <h3 class="testimonials-one__name">Barbara Kennedy</h3><!-- /.testimonials-one__name -->
                      <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                  </div><!-- /.testimonials-one__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="testimonials-one__single">
                      <div class="testimonials-one__qoute">
                          <img src="/assets/images/qoute-1-1.png" alt="">
                      </div><!-- /.testimonials-one__qoute -->
                      <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                          the majority have suffered alteration in some form, by injected humour.</p>
                      <!-- /.testimonials-one__text -->
                      <img src="/assets/images/team-1-6.jpg" alt="" class="testimonials-one__img">
                      <h3 class="testimonials-one__name">Duane Carter</h3><!-- /.testimonials-one__name -->
                      <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                  </div><!-- /.testimonials-one__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="testimonials-one__single">
                      <div class="testimonials-one__qoute">
                          <img src="/assets/images/qoute-1-1.png" alt="">
                      </div><!-- /.testimonials-one__qoute -->
                      <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                          the majority.</p><!-- /.testimonials-one__text -->
                      <img src="/assets/images/team-1-1.jpg" alt="" class="testimonials-one__img">
                      <h3 class="testimonials-one__name">Sally Green</h3><!-- /.testimonials-one__name -->
                      <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                  </div><!-- /.testimonials-one__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="testimonials-one__single">
                      <div class="testimonials-one__qoute">
                          <img src="/assets/images/qoute-1-1.png" alt="">
                      </div><!-- /.testimonials-one__qoute -->
                      <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                          the majority have suffered alteration in some form.</p><!-- /.testimonials-one__text -->
                      <img src="/assets/images/team-1-2.jpg" alt="" class="testimonials-one__img">
                      <h3 class="testimonials-one__name">Iva Santos</h3><!-- /.testimonials-one__name -->
                      <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                  </div><!-- /.testimonials-one__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="testimonials-one__single">
                      <div class="testimonials-one__qoute">
                          <img src="/assets/images/qoute-1-1.png" alt="">
                      </div><!-- /.testimonials-one__qoute -->
                      <p class="testimonials-one__text">There are many variations of passages of lore ipsu available but
                          the majority have suffered alteration in some form, by injected humour.</p>
                      <!-- /.testimonials-one__text -->
                      <img src="/assets/images/team-1-3.jpg" alt="" class="testimonials-one__img">
                      <h3 class="testimonials-one__name">Max Burns</h3><!-- /.testimonials-one__name -->
                      <p class="testimonials-one__designation">Student</p><!-- /.testimonials-one__designation -->
                  </div><!-- /.testimonials-one__single -->
              </div><!-- /.item -->
          </div><!-- /.testimonials-one__carousel owl-carousel owl-theme -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "Testimonial"
    }
</script>

<style scoped>

</style>
