<template>
  <section class="blog-two">
      <div class="container">
          <div class="block-title text-center">
              <h2 class="block-title__title">Our latest projects <br>
                  </h2><!-- /.block-title__title -->
          </div><!-- /.block-title -->
          <div class="blog-two__carousel owl-carousel owl-theme">
              <div class="item">
                  <div class="blog-two__single" :style="{backgroundImage: `url(assets/images/blog-2-1-1.jpg)`}">
                      <div class="blog-two__inner">
                          <a href="/news-details" class="blog-two__date">
                              <span>25</span>
                              Jul
                          </a><!-- /.blog-two__date -->
                          <div class="blog-two__meta">
                              <a href="#">by Admin</a>
                              <a href="#">3 Comments</a>
                          </div><!-- /.blog-two__meta -->
                          <h3 class="blog-two__title">
                              <a href="/news-details">Textile solution in Kenya</a>
                          </h3><!-- /.blog-two__title -->
                      </div><!-- /.blog-two__inner -->
                  </div><!-- /.blog-two__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="blog-two__single" :style="{backgroundImage: `url(assets/images/blog-2-2-2.jpg)`}">
                      <div class="blog-two__inner">
                          <a href="/news-details" class="blog-two__date">
                              <span>25</span>
                              Jul
                          </a><!-- /.blog-two__date -->
                          <div class="blog-two__meta">
                              <a href="#">by Admin</a>
                              <a href="#">3 Comments</a>
                          </div><!-- /.blog-two__meta -->
                          <h3 class="blog-two__title">
                              <a href="/news-details">Farmers support in Congo</a>
                          </h3><!-- /.blog-two__title -->
                      </div><!-- /.blog-two__inner -->
                  </div><!-- /.blog-two__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="blog-two__single" :style="{backgroundImage: `url(assets/images/blog-2-3-3.jpg)`}">
                      <div class="blog-two__inner">
                          <a href="/news-details" class="blog-two__date">
                              <span>25</span>
                              Jul
                          </a><!-- /.blog-two__date -->
                          <div class="blog-two__meta">
                              <a href="#">by Admin</a>
                              <a href="#">3 Comments</a>
                          </div><!-- /.blog-two__meta -->
                          <h3 class="blog-two__title">
                              <a href="/news-details"> Water projects in Sudan</a>
                          </h3><!-- /.blog-two__title -->
                      </div><!-- /.blog-two__inner -->
                  </div><!-- /.blog-two__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="blog-two__single" :style="{backgroundImage: `url(assets/images/blog-2-1-1.jpg)`}">
                      <div class="blog-two__inner">
                          <a href="/news-details" class="blog-two__date">
                              <span>25</span>
                              Jul
                          </a><!-- /.blog-two__date -->
                          <div class="blog-two__meta">
                              <a href="#">by Admin</a>
                              <a href="#">3 Comments</a>
                          </div><!-- /.blog-two__meta -->
                          <h3 class="blog-two__title">
                              <a href="/news-details">Textile solution in Kenya</a>
                          </h3><!-- /.blog-two__title -->
                      </div><!-- /.blog-two__inner -->
                  </div><!-- /.blog-two__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="blog-two__single" :style="{backgroundImage: `url(assets/images/blog-2-2-2.jpg)`}">
                      <div class="blog-two__inner">
                          <a href="/news-details" class="blog-two__date">
                              <span>25</span>
                              Jul
                          </a><!-- /.blog-two__date -->
                          <div class="blog-two__meta">
                              <a href="#">by Admin</a>
                              <a href="#">3 Comments</a>
                          </div><!-- /.blog-two__meta -->
                          <h3 class="blog-two__title">
                              <a href="/news-details">Farmers support in Congo</a>
                          </h3><!-- /.blog-two__title -->
                      </div><!-- /.blog-two__inner -->
                  </div><!-- /.blog-two__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="blog-two__single" :style="{backgroundImage: `url(assets/images/blog-2-3-3.jpg)`}">
                      <div class="blog-two__inner">
                          <a href="/news-details" class="blog-two__date">
                              <span>25</span>
                              Jul
                          </a><!-- /.blog-two__date -->
                          <div class="blog-two__meta">
                              <a href="#">by Admin</a>
                              <a href="#">3 Comments</a>
                          </div><!-- /.blog-two__meta -->
                          <h3 class="blog-two__title">
                              <a href="/news-details">Water projects in Sudan</a>
                          </h3><!-- /.blog-two__title -->
                      </div><!-- /.blog-two__inner -->
                  </div><!-- /.blog-two__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="blog-two__single" :style="{backgroundImage: `url(assets/images/blog-2-1-1.jpg)`}">
                      <div class="blog-two__inner">
                          <a href="/news-details" class="blog-two__date">
                              <span>25</span>
                              Jul
                          </a><!-- /.blog-two__date -->
                          <div class="blog-two__meta">
                              <a href="#">by Admin</a>
                              <a href="#">3 Comments</a>
                          </div><!-- /.blog-two__meta -->
                          <h3 class="blog-two__title">
                              <a href="/news-details">Textile solution in Kenya</a>
                          </h3><!-- /.blog-two__title -->
                      </div><!-- /.blog-two__inner -->
                  </div><!-- /.blog-two__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="blog-two__single" :style="{backgroundImage: `url(assets/images/blog-2-2-2.jpg)`}">
                      <div class="blog-two__inner">
                          <a href="/news-details" class="blog-two__date">
                              <span>25</span>
                              Jul
                          </a><!-- /.blog-two__date -->
                          <div class="blog-two__meta">
                              <a href="#">by Admin</a>
                              <a href="#">3 Comments</a>
                          </div><!-- /.blog-two__meta -->
                          <h3 class="blog-two__title">
                              <a href="/news-details">Farmers support in Congo</a>
                          </h3><!-- /.blog-two__title -->
                      </div><!-- /.blog-two__inner -->
                  </div><!-- /.blog-two__single -->
              </div><!-- /.item -->
              <div class="item">
                  <div class="blog-two__single" :style="{backgroundImage: `url(assets/images/blog-2-3-3.jpg)`}">
                      <div class="blog-two__inner">
                          <a href="/news-details" class="blog-two__date">
                              <span>25</span>
                              Jul
                          </a><!-- /.blog-two__date -->
                          <div class="blog-two__meta">
                              <a href="#">by Admin</a>
                              <a href="#">3 Comments</a>
                          </div><!-- /.blog-two__meta -->
                          <h3 class="blog-two__title">
                              <a href="/news-details">Water projects in Sudan</a>
                          </h3><!-- /.blog-two__title -->
                      </div><!-- /.blog-two__inner -->
                  </div><!-- /.blog-two__single -->
              </div><!-- /.item -->
          </div><!-- /.blog-two__carousel owl-carousel owl-theme -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "BlogCarousel"
    }
</script>

<style scoped>

</style>
