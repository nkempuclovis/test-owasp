<template>
  <section class="faq-one">
      <div class="container">
          <div class="row no-gutters">
              <div class="col-lg-6">
                  <div class="faq-one__single">
                      <div class="faq-one__icon">
                          <span>?</span>
                      </div><!-- /.faq-one__icon -->
                      <div class="faq-one__content">
                          <h2 class="faq-one__title">How long are your contracts?</h2><!-- /.faq-one__title -->
                          <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                              subscription at any time from within your
                              dashboard.</p><!-- /.faq-one__text -->
                      </div><!-- /.faq-one__content -->
                  </div><!-- /.faq-one__single -->
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-6">
                  <div class="faq-one__single">
                      <div class="faq-one__icon">
                          <span>?</span>
                      </div><!-- /.faq-one__icon -->
                      <div class="faq-one__content">
                          <h2 class="faq-one__title">How long are your contracts?</h2><!-- /.faq-one__title -->
                          <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                              subscription at any time from within your
                              dashboard.</p><!-- /.faq-one__text -->
                      </div><!-- /.faq-one__content -->
                  </div><!-- /.faq-one__single -->
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-6">
                  <div class="faq-one__single">
                      <div class="faq-one__icon">
                          <span>?</span>
                      </div><!-- /.faq-one__icon -->
                      <div class="faq-one__content">
                          <h2 class="faq-one__title">How long are your contracts?</h2><!-- /.faq-one__title -->
                          <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                              subscription at any time from within your
                              dashboard.</p><!-- /.faq-one__text -->
                      </div><!-- /.faq-one__content -->
                  </div><!-- /.faq-one__single -->
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-6">
                  <div class="faq-one__single">
                      <div class="faq-one__icon">
                          <span>?</span>
                      </div><!-- /.faq-one__icon -->
                      <div class="faq-one__content">
                          <h2 class="faq-one__title">How long are your contracts?</h2><!-- /.faq-one__title -->
                          <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                              subscription at any time from within your
                              dashboard.</p><!-- /.faq-one__text -->
                      </div><!-- /.faq-one__content -->
                  </div><!-- /.faq-one__single -->
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-6" style="padding-bottom: 0px; border-bottom: 0px none;">
                  <div class="faq-one__single">
                      <div class="faq-one__icon">
                          <span>?</span>
                      </div><!-- /.faq-one__icon -->
                      <div class="faq-one__content">
                          <h2 class="faq-one__title">How long are your contracts?</h2><!-- /.faq-one__title -->
                          <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                              subscription at any time from within your
                              dashboard.</p><!-- /.faq-one__text -->
                      </div><!-- /.faq-one__content -->
                  </div><!-- /.faq-one__single -->
              </div><!-- /.col-lg-6 -->
              <div class="col-lg-6" style="padding-bottom: 0px; border-bottom: 0px none;">
                  <div class="faq-one__single">
                      <div class="faq-one__icon">
                          <span>?</span>
                      </div><!-- /.faq-one__icon -->
                      <div class="faq-one__content">
                          <h2 class="faq-one__title">How long are your contracts?</h2><!-- /.faq-one__title -->
                          <p class="faq-one__text">We don't do contracts. You can cancel your monthly or annual
                              subscription at any time from within your
                              dashboard.</p><!-- /.faq-one__text -->
                      </div><!-- /.faq-one__content -->
                  </div><!-- /.faq-one__single -->
              </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "Faq"
    }
</script>

<style scoped>

</style>
