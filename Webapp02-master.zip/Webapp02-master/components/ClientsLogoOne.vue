<template>
  <section class="brand-one brand-one__home-three">
              <div class="container">
                  <div class="brand-one__carousel owl-carousel owl-theme">
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                      <div class="item">
                          <img src="/assets/images/brand-1-1.png" alt="">
                      </div><!-- /.item -->
                  </div><!-- /.brand-one__carousel owl-carousel owl-theme -->
              </div><!-- /.container -->
          </section>
</template>

<script>
    export default {
        name: "ClientsLogoOne"
    }
</script>

<style scoped>

</style>
