<template>
  <section class="gallery-one">
      <div class="container">
          <div class="row">
              <div class="col-lg-4 col-md-6">
                  <div class="gallery-one__single">
                      <img src="/assets/images/gallery1.jpg" alt="">
                      <a href="/assets/images/gallery1.jpg" class="gallery-one__popup img-popup"><i class="kipso-icon-plus-symbol"></i><!-- /.kipso-icon-plus-symbol --></a>
                  </div><!-- /.gallery-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4 col-md-6">
                  <div class="gallery-one__single">
                      <img src="/assets/images/gallery2.jpg" alt="">
                      <a href="/assets/images/gallery2.jpg" class="gallery-one__popup img-popup"><i class="kipso-icon-plus-symbol"></i><!-- /.kipso-icon-plus-symbol --></a>
                  </div><!-- /.gallery-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4 col-md-6">
                  <div class="gallery-one__single">
                      <img src="/assets/images/gallery3.jpg" alt="">
                      <a href="/assets/images/gallery3.jpg" class="gallery-one__popup img-popup"><i class="kipso-icon-plus-symbol"></i><!-- /.kipso-icon-plus-symbol --></a>
                  </div><!-- /.gallery-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4 col-md-6">
                  <div class="gallery-one__single">
                      <img src="/assets/images/gallery4.jpg" alt="">
                      <a href="/assets/images/gallery4.jpg" class="gallery-one__popup img-popup"><i class="kipso-icon-plus-symbol"></i><!-- /.kipso-icon-plus-symbol --></a>
                  </div><!-- /.gallery-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4 col-md-6">
                  <div class="gallery-one__single">
                      <img src="/assets/images/gallery5.jpg" alt="">
                      <a href="/assets/images/gallery5.jpg" class="gallery-one__popup img-popup"><i class="kipso-icon-plus-symbol"></i><!-- /.kipso-icon-plus-symbol --></a>
                  </div><!-- /.gallery-one__single -->
              </div><!-- /.col-lg-4 -->
              <div class="col-lg-4 col-md-6">
                  <div class="gallery-one__single">
                      <img src="/assets/images/gallery6.jpg" alt="">
                      <a href="/assets/images/gallery6.jpg" class="gallery-one__popup img-popup"><i class="kipso-icon-plus-symbol"></i><!-- /.kipso-icon-plus-symbol --></a>
                  </div><!-- /.gallery-one__single -->
              </div><!-- /.col-lg-4 -->
             
             
            
          </div><!-- /.row -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "Gallery"
    }
</script>

<style scoped>

</style>
