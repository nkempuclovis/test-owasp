<template>
  <section class="brand-two ">
      <div class="container">
          <div class="block-title">
              <h2 class="block-title__title">Our company & partners</h2><!-- /.block-title__title -->
          </div><!-- /.block-title -->
          <div class="brand-one__carousel owl-carousel owl-theme">
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
              <div class="item">
                  <img src="/assets/images/brand-1-1.png" alt="">
              </div><!-- /.item -->
          </div><!-- /.brand-one__carousel owl-carousel owl-theme -->
      </div><!-- /.container -->
  </section>
</template>

<script>
    export default {
        name: "ClientsLogoTwo"
    }
</script>

<style scoped>

</style>
